package prog5121poe;
import java.util.Scanner;

public class PROG5121POE {
    private static String savedUsername;
    private static String savedPassword;
    private static String savedFirstName;
    private static String savedLastName;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.println("|||REGISTRATION|||");
        
       
        
        // Account creation
        System.out.println("Enter username:");
        String username = input.nextLine();
        
        System.out.println("Enter password:");
        String password = input.nextLine();
        
        // Check username
        if (username.contains("_") && username.length() <= 5) {
            System.out.println("Username successfully captured");
            savedUsername = username; // Save the username
        } else {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            return; // Exit if username is not valid
        }
        
        // Check password
        if (password.length() >= 8 && 
            password.matches(".*[A-Z].*") && 
            password.matches(".*[0-9].*") && 
            password.matches(".*[!@#$%^&*()_+].*")) {
            System.out.println("Password successfully captured");
            savedPassword = password; // Save the password
        } else {
            System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            return; // Exit if password is not valid
        }
        
        
        // Capture first name and last name
        System.out.println("Enter first name:");
        savedFirstName = input.nextLine();

        System.out.println("Enter last name:");
        savedLastName = input.nextLine();
        System.out.println();
        
        System.out.println("|||LOGIN|||");
        
        // Login functionality
        System.out.println("Please login with your username and password.");
        
        System.out.println("Enter username:");
        String loginUsername = input.nextLine();
        
        System.out.println("Enter password:");
        String loginPassword = input.nextLine();
        
        // Authenticate user
        authenticate(loginUsername, loginPassword);
    }
    
    private static void authenticate(String username, String password) {
        if (username.equals(savedUsername) && password.equals(savedPassword)) {
            System.out.println("Welcome " + savedFirstName + ", " + savedLastName + " it is great to see you again.");
        } else {
            System.out.println("Username or password incorrect, please try again");
        }
    }
}